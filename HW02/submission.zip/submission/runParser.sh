#!/bin/bash

# Run the JSON parser on the full dataset
python3 json_parser.py ebay_data/items-*.json
