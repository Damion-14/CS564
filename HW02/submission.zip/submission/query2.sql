SELECT COUNT(*) FROM users u 
WHERE u.location = 'New York';