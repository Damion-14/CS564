SELECT item_id, currently as 'Currently $' FROM item
ORDER BY currently desc
LIMIT 10;